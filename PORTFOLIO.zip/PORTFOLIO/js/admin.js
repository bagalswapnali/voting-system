import {
  ADMIN_CREDENTIALS,
  addCandidate,
  clearAdminSession,
  getAdminSession,
  getCandidates,
  getTheme,
  getVoteStats,
  initializeStorage,
  removeCandidate,
  resetVotes,
  setAdminSession,
  setTheme
} from "./storage.js";

function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast-item ${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add("show"));
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 250);
  }, 2600);
}

function applyTheme(theme) {
  document.documentElement.classList.toggle("dark", theme === "dark");
  const icon = document.getElementById("theme-icon");
  if (icon) icon.textContent = theme === "dark" ? "Light" : "Dark";
}

function setupThemeToggle() {
  applyTheme(getTheme());
  const button = document.getElementById("theme-toggle");
  button.addEventListener("click", () => {
    const nextTheme = document.documentElement.classList.contains("dark") ? "light" : "dark";
    setTheme(nextTheme);
    applyTheme(nextTheme);
  });
}

function renderCandidates() {
  const list = document.getElementById("candidate-list");
  const candidates = getCandidates();
  list.innerHTML = "";

  if (candidates.length === 0) {
    list.innerHTML = "<p class='text-slate-500 dark:text-slate-300'>No candidates yet.</p>";
    return;
  }

  candidates.forEach((candidate) => {
    const item = document.createElement("div");
    item.className = "flex items-center justify-between rounded-xl border border-slate-200 bg-white/70 px-4 py-3 dark:border-slate-700 dark:bg-slate-800/70";

    item.innerHTML = `
      <div>
        <p class="font-semibold text-slate-900 dark:text-white">${candidate.name} <span class="ml-2 text-sky-600 dark:text-sky-300">(${candidate.symbol})</span></p>
        <p class="text-sm text-slate-500 dark:text-slate-300">${candidate.party}</p>
      </div>
      <button class="rounded-lg bg-rose-500 px-3 py-1.5 text-sm font-medium text-white hover:bg-rose-600" data-id="${candidate.id}">Remove</button>
    `;

    item.querySelector("button").addEventListener("click", () => {
      removeCandidate(candidate.id);
      showToast("Candidate removed.", "success");
      renderCandidates();
      renderStats();
    });

    list.appendChild(item);
  });
}

function renderStats() {
  const stats = getVoteStats();
  document.getElementById("total-votes").textContent = stats.totalVotes;
  document.getElementById("total-candidates").textContent = getCandidates().length;
}

function showDashboard() {
  document.getElementById("admin-login-section").classList.add("hidden");
  document.getElementById("admin-dashboard").classList.remove("hidden");
  renderCandidates();
  renderStats();
}

function setupAdminLogin() {
  const loginForm = document.getElementById("admin-login-form");
  loginForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const email = document.getElementById("admin-email").value.trim().toLowerCase();
    const password = document.getElementById("admin-password").value;

    if (email !== ADMIN_CREDENTIALS.email || password !== ADMIN_CREDENTIALS.password) {
      showToast("Invalid admin credentials.", "error");
      return;
    }

    setAdminSession(true);
    showToast("Admin logged in.", "success");
    showDashboard();
  });
}

function setupCandidateForm() {
  const form = document.getElementById("candidate-form");
  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const name = document.getElementById("candidate-name").value.trim();
    const party = document.getElementById("candidate-party").value.trim();
    const symbol = document.getElementById("candidate-symbol").value.trim();

    if (!name || !party) {
      showToast("Name and party are required.", "error");
      return;
    }

    addCandidate({ name, party, symbol });
    showToast("Candidate added.", "success");
    form.reset();
    renderCandidates();
    renderStats();
  });
}

function setupControls() {
  document.getElementById("reset-votes-btn").addEventListener("click", () => {
    const okay = window.confirm("Reset all voting data? This cannot be undone.");
    if (!okay) return;

    resetVotes();
    showToast("Voting data reset.", "success");
    renderStats();
  });

  document.getElementById("admin-logout-btn").addEventListener("click", () => {
    clearAdminSession();
    window.location.reload();
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initializeStorage();
  setupThemeToggle();
  setupAdminLogin();
  setupCandidateForm();
  setupControls();

  if (getAdminSession()) {
    showDashboard();
  }

  const loader = document.getElementById("page-loader");
  setTimeout(() => loader.classList.add("hidden"), 450);
});
