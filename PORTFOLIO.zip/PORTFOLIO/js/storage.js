// Centralized keys keep localStorage usage consistent across all modules.
const STORAGE_KEYS = {
	users: "ovs_users",
	currentUser: "ovs_current_user",
	candidates: "ovs_candidates",
	votes: "ovs_votes",
	adminSession: "ovs_admin_session",
	theme: "ovs_theme"
};

export const ADMIN_CREDENTIALS = {
	email: "admin@votehub.com",
	password: "Admin@123"
};

const DEFAULT_CANDIDATES = [
	{
		id: "cand_1",
		name: "Aarav Sharma",
		party: "Forward India Party",
			symbol: "Sun"
	},
	{
		id: "cand_2",
		name: "Meera Nair",
		party: "Green Future Alliance",
			symbol: "Leaf"
	},
	{
		id: "cand_3",
		name: "Rohan Verma",
		party: "People's Progress Front",
			symbol: "Book"
	}
];

function safeParse(value, fallback) {
	try {
		return value ? JSON.parse(value) : fallback;
	} catch {
		return fallback;
	}
}

export function initializeStorage() {
	if (!localStorage.getItem(STORAGE_KEYS.candidates)) {
		setCandidates(DEFAULT_CANDIDATES);
	}

	if (!localStorage.getItem(STORAGE_KEYS.users)) {
		setUsers([]);
	}

	if (!localStorage.getItem(STORAGE_KEYS.votes)) {
		setVotes({});
	}
}

export function getUsers() {
	return safeParse(localStorage.getItem(STORAGE_KEYS.users), []);
}

export function setUsers(users) {
	localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(users));
}

export function addUser({ name, email, password }) {
	const users = getUsers();
	const normalizedEmail = email.trim().toLowerCase();
	const alreadyExists = users.some((user) => user.email === normalizedEmail);

	if (alreadyExists) {
		return { success: false, message: "An account already exists with this email." };
	}

	const newUser = {
		id: `user_${Date.now()}`,
		name: name.trim(),
		email: normalizedEmail,
		password,
		createdAt: new Date().toISOString()
	};

	users.push(newUser);
	setUsers(users);

	return { success: true, user: newUser };
}

export function authenticateUser(email, password) {
	const users = getUsers();
	const normalizedEmail = email.trim().toLowerCase();
	return users.find((user) => user.email === normalizedEmail && user.password === password) || null;
}

export function setCurrentUser(user) {
	localStorage.setItem(STORAGE_KEYS.currentUser, JSON.stringify(user));
}

export function getCurrentUser() {
	return safeParse(localStorage.getItem(STORAGE_KEYS.currentUser), null);
}

export function clearCurrentUser() {
	localStorage.removeItem(STORAGE_KEYS.currentUser);
}

export function getCandidates() {
	return safeParse(localStorage.getItem(STORAGE_KEYS.candidates), []);
}

export function setCandidates(candidates) {
	localStorage.setItem(STORAGE_KEYS.candidates, JSON.stringify(candidates));
}

export function addCandidate({ name, party, symbol }) {
	const candidates = getCandidates();
	const safeSymbol = typeof symbol === "string" ? symbol.trim() : "";
	const candidate = {
		id: `cand_${Date.now()}`,
		name: name.trim(),
		party: party.trim(),
		symbol: safeSymbol || "Vote"
	};

	candidates.push(candidate);
	setCandidates(candidates);
	return candidate;
}

export function removeCandidate(candidateId) {
	const candidates = getCandidates().filter((candidate) => candidate.id !== candidateId);
	setCandidates(candidates);

	// Remove votes for deleted candidate to keep results accurate.
	const votes = getVotes();
	Object.keys(votes).forEach((email) => {
		if (votes[email] === candidateId) {
			delete votes[email];
		}
	});
	setVotes(votes);
}

export function getVotes() {
	return safeParse(localStorage.getItem(STORAGE_KEYS.votes), {});
}

export function setVotes(votes) {
	localStorage.setItem(STORAGE_KEYS.votes, JSON.stringify(votes));
}

export function hasUserVoted(email) {
	const votes = getVotes();
	return Boolean(votes[email.trim().toLowerCase()]);
}

export function castVote(email, candidateId) {
	const normalizedEmail = email.trim().toLowerCase();
	const votes = getVotes();

	if (votes[normalizedEmail]) {
		return { success: false, message: "You have already cast your vote." };
	}

	votes[normalizedEmail] = candidateId;
	setVotes(votes);
	return { success: true };
}

export function resetVotes() {
	setVotes({});
}

export function getVoteStats() {
	const candidates = getCandidates();
	const votes = getVotes();
	const totalVotes = Object.keys(votes).length;

	const candidateStats = candidates.map((candidate) => {
		const count = Object.values(votes).filter((votedId) => votedId === candidate.id).length;
		const percentage = totalVotes === 0 ? 0 : (count / totalVotes) * 100;

		return {
			...candidate,
			count,
			percentage
		};
	});

	const sorted = [...candidateStats].sort((a, b) => b.count - a.count);
	const winner = sorted.length > 0 ? sorted[0] : null;
	const isTie = sorted.length > 1 && sorted[0].count === sorted[1].count;

	return {
		totalVotes,
		candidateStats,
		winner,
		isTie
	};
}

export function setTheme(theme) {
	localStorage.setItem(STORAGE_KEYS.theme, theme);
}

export function getTheme() {
	return localStorage.getItem(STORAGE_KEYS.theme) || "light";
}

export function setAdminSession(isLoggedIn) {
	localStorage.setItem(STORAGE_KEYS.adminSession, JSON.stringify(Boolean(isLoggedIn)));
}

export function getAdminSession() {
	return safeParse(localStorage.getItem(STORAGE_KEYS.adminSession), false);
}

export function clearAdminSession() {
	localStorage.removeItem(STORAGE_KEYS.adminSession);
}
