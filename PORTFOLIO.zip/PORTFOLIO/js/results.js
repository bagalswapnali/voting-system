import {
  getCandidates,
  getTheme,
  getVoteStats,
  initializeStorage,
  setTheme
} from "./storage.js";

let chartInstance = null;

function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast-item ${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add("show"));
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 250);
  }, 2500);
}

function applyTheme(theme) {
  document.documentElement.classList.toggle("dark", theme === "dark");
  const icon = document.getElementById("theme-icon");
  if (icon) icon.textContent = theme === "dark" ? "Light" : "Dark";
}

function setupThemeToggle() {
  applyTheme(getTheme());
  const button = document.getElementById("theme-toggle");
  button.addEventListener("click", () => {
    const nextTheme = document.documentElement.classList.contains("dark") ? "light" : "dark";
    setTheme(nextTheme);
    applyTheme(nextTheme);
    renderResults();
  });
}

function renderWinner(stats) {
  const winnerBox = document.getElementById("winner-box");

  if (stats.totalVotes === 0) {
    winnerBox.innerHTML = "<p class='text-slate-600 dark:text-slate-300'>No votes have been cast yet.</p>";
    return;
  }

  if (stats.isTie) {
    winnerBox.innerHTML = "<p class='text-amber-600 dark:text-amber-300 font-semibold'>It is a tie. Additional voting round may be needed.</p>";
    return;
  }

  winnerBox.innerHTML = `
    <p class="text-sm uppercase tracking-wider text-slate-500 dark:text-slate-300">Winning Candidate</p>
    <h3 class="mt-1 text-2xl font-semibold text-slate-900 dark:text-white">${stats.winner.name}</h3>
    <p class="text-slate-600 dark:text-slate-300">${stats.winner.party} - ${stats.winner.count} votes (${stats.winner.percentage.toFixed(1)}%)</p>
  `;
}

function renderBreakdown(stats) {
  const list = document.getElementById("result-breakdown");
  list.innerHTML = "";

  stats.candidateStats.forEach((candidate, index) => {
    const row = document.createElement("div");
    row.className = "rounded-xl border border-slate-200 bg-white/70 p-4 dark:border-slate-700 dark:bg-slate-800/70 fade-in";
    row.style.animationDelay = `${index * 70}ms`;

    row.innerHTML = `
      <div class="mb-2 flex items-center justify-between">
        <p class="font-medium text-slate-900 dark:text-white">${candidate.name} <span class="text-sky-600 dark:text-sky-300">(${candidate.symbol})</span></p>
        <p class="text-sm text-slate-500 dark:text-slate-300">${candidate.count} votes</p>
      </div>
      <div class="h-2.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
        <div class="h-full rounded-full bg-sky-500" style="width: ${candidate.percentage.toFixed(1)}%"></div>
      </div>
      <p class="mt-2 text-right text-sm text-slate-600 dark:text-slate-300">${candidate.percentage.toFixed(1)}%</p>
    `;

    list.appendChild(row);
  });
}

function renderChart(stats) {
  const canvas = document.getElementById("results-chart");
  const ctx = canvas.getContext("2d");
  const labels = stats.candidateStats.map((candidate) => candidate.name);
  const values = stats.candidateStats.map((candidate) => candidate.count);

  if (chartInstance) {
    chartInstance.destroy();
  }

  const textColor = document.documentElement.classList.contains("dark") ? "#e2e8f0" : "#0f172a";

  chartInstance = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [
        {
          label: "Votes",
          data: values,
          backgroundColor: ["#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#6366f1"],
          borderRadius: 10,
          maxBarThickness: 56
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: textColor
          }
        }
      },
      scales: {
        x: {
          ticks: { color: textColor },
          grid: { display: false }
        },
        y: {
          beginAtZero: true,
          ticks: { color: textColor, precision: 0 },
          grid: { color: "rgba(148, 163, 184, 0.25)" }
        }
      }
    }
  });
}

function renderResults() {
  const candidates = getCandidates();
  const stats = getVoteStats();

  document.getElementById("total-votes").textContent = stats.totalVotes;
  document.getElementById("total-candidates").textContent = candidates.length;

  renderWinner(stats);
  renderBreakdown(stats);
  renderChart(stats);
}

document.addEventListener("DOMContentLoaded", () => {
  initializeStorage();
  setupThemeToggle();
  renderResults();

  document.getElementById("refresh-results").addEventListener("click", () => {
    renderResults();
    showToast("Results refreshed.", "success");
  });

  const loader = document.getElementById("page-loader");
  setTimeout(() => loader.classList.add("hidden"), 450);
});
