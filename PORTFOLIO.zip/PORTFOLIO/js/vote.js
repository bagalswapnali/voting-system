import {
  castVote,
  clearCurrentUser,
  getCandidates,
  getCurrentUser,
  getTheme,
  hasUserVoted,
  initializeStorage,
  setTheme
} from "./storage.js";

let selectedCandidateId = null;

function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast-item ${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add("show"));
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 250);
  }, 2600);
}

function applyTheme(theme) {
  document.documentElement.classList.toggle("dark", theme === "dark");
  const icon = document.getElementById("theme-icon");
  if (icon) icon.textContent = theme === "dark" ? "Light" : "Dark";
}

function setupThemeToggle() {
  applyTheme(getTheme());
  const button = document.getElementById("theme-toggle");

  button.addEventListener("click", () => {
    const nextTheme = document.documentElement.classList.contains("dark") ? "light" : "dark";
    setTheme(nextTheme);
    applyTheme(nextTheme);
  });
}

function renderCandidates(userEmail) {
  const candidateGrid = document.getElementById("candidate-grid");
  const voted = hasUserVoted(userEmail);
  const candidates = getCandidates();

  candidateGrid.innerHTML = "";

  if (candidates.length === 0) {
    candidateGrid.innerHTML = `
      <div class="col-span-full rounded-2xl border border-dashed border-slate-400/60 p-8 text-center text-slate-500 dark:text-slate-300">
        No candidates available right now. Please contact admin.
      </div>
    `;
    return;
  }

  candidates.forEach((candidate, index) => {
    const card = document.createElement("article");
    card.className = "candidate-card fade-in";
    card.style.animationDelay = `${index * 80}ms`;

    card.innerHTML = `
      <div class="text-4xl font-bold tracking-wide text-sky-600 dark:text-sky-300">${candidate.symbol}</div>
      <h3 class="mt-3 text-xl font-semibold text-slate-900 dark:text-white">${candidate.name}</h3>
      <p class="text-sm text-slate-500 dark:text-slate-300">${candidate.party}</p>
      <button
        class="vote-btn mt-5 w-full rounded-xl px-4 py-2.5 font-medium transition"
        data-id="${candidate.id}"
        ${voted ? "disabled" : ""}
      >
        ${voted ? "Vote Locked" : "Vote Now"}
      </button>
    `;

    candidateGrid.appendChild(card);
  });

  if (!voted) {
    candidateGrid.querySelectorAll(".vote-btn").forEach((button) => {
      button.addEventListener("click", () => {
        selectedCandidateId = button.dataset.id;
        openConfirmModal();
      });
    });
  }
}

function openConfirmModal() {
  const modal = document.getElementById("confirm-modal");
  modal.classList.add("flex");
  modal.classList.remove("hidden");
}

function closeConfirmModal() {
  const modal = document.getElementById("confirm-modal");
  modal.classList.remove("flex");
  modal.classList.add("hidden");
  selectedCandidateId = null;
}

function setupVoteActions(user) {
  const voted = hasUserVoted(user.email);
  const status = document.getElementById("vote-status");

  status.textContent = voted
    ? "You have already submitted your vote."
    : "Choose one candidate to cast your vote.";

  document.getElementById("confirm-vote").addEventListener("click", () => {
    if (!selectedCandidateId) return;

    const result = castVote(user.email, selectedCandidateId);
    if (!result.success) {
      showToast(result.message, "error");
      closeConfirmModal();
      renderCandidates(user.email);
      return;
    }

    showToast("Vote submitted successfully.", "success");
    closeConfirmModal();
    renderCandidates(user.email);
    document.getElementById("vote-status").textContent = "You have already submitted your vote.";
  });

  document.getElementById("cancel-vote").addEventListener("click", closeConfirmModal);

  document.getElementById("logout-btn").addEventListener("click", () => {
    clearCurrentUser();
    window.location.href = "index.html";
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initializeStorage();

  const user = getCurrentUser();
  if (!user) {
    window.location.href = "index.html";
    return;
  }

  setupThemeToggle();
  document.getElementById("welcome-user").textContent = user.name;
  renderCandidates(user.email);
  setupVoteActions(user);

  const loader = document.getElementById("page-loader");
  setTimeout(() => loader.classList.add("hidden"), 450);
});
