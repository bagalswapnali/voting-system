import {
  addUser,
  authenticateUser,
  getCurrentUser,
  initializeStorage,
  setCurrentUser,
  getTheme,
  setTheme
} from "./storage.js";

function showToast(message, type = "info") {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast-item ${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.add("show");
  });

  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 250);
  }, 2800);
}

function applyTheme(theme) {
  document.documentElement.classList.toggle("dark", theme === "dark");
  const icon = document.getElementById("theme-icon");
  if (icon) {
    icon.textContent = theme === "dark" ? "Light" : "Dark";
  }
}

function setupThemeToggle() {
  const toggle = document.getElementById("theme-toggle");
  const initialTheme = getTheme();
  applyTheme(initialTheme);

  if (!toggle) return;

  toggle.addEventListener("click", () => {
    const current = document.documentElement.classList.contains("dark") ? "dark" : "light";
    const next = current === "dark" ? "light" : "dark";
    setTheme(next);
    applyTheme(next);
  });
}

function switchTab(tabName) {
  const loginPanel = document.getElementById("login-panel");
  const registerPanel = document.getElementById("register-panel");
  const loginTab = document.getElementById("login-tab");
  const registerTab = document.getElementById("register-tab");

  const isLogin = tabName === "login";
  loginPanel.classList.toggle("hidden", !isLogin);
  registerPanel.classList.toggle("hidden", isLogin);

  loginTab.classList.toggle("active-tab", isLogin);
  registerTab.classList.toggle("active-tab", !isLogin);
}

function validateRegistration(name, email, password) {
  if (name.trim().length < 2) {
    return "Name should be at least 2 characters.";
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email.trim())) {
    return "Enter a valid email address.";
  }

  if (password.length < 6) {
    return "Password must be at least 6 characters.";
  }

  return null;
}

function setupAuthHandlers() {
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");
  const loginTab = document.getElementById("login-tab");
  const registerTab = document.getElementById("register-tab");

  loginTab.addEventListener("click", () => switchTab("login"));
  registerTab.addEventListener("click", () => switchTab("register"));

  registerForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const name = document.getElementById("register-name").value;
    const email = document.getElementById("register-email").value;
    const password = document.getElementById("register-password").value;

    const error = validateRegistration(name, email, password);
    if (error) {
      showToast(error, "error");
      return;
    }

    const result = addUser({ name, email, password });
    if (!result.success) {
      showToast(result.message, "error");
      return;
    }

    showToast("Registration successful. Please login.", "success");
    registerForm.reset();
    switchTab("login");
  });

  loginForm.addEventListener("submit", (event) => {
    event.preventDefault();

    const email = document.getElementById("login-email").value;
    const password = document.getElementById("login-password").value;

    const user = authenticateUser(email, password);
    if (!user) {
      showToast("Invalid email or password.", "error");
      return;
    }

    setCurrentUser({ id: user.id, name: user.name, email: user.email });
    showToast("Login successful. Redirecting...", "success");

    setTimeout(() => {
      window.location.href = "vote.html";
    }, 800);
  });
}

function setupAutoRedirect() {
  const user = getCurrentUser();
  if (user) {
    const continueButton = document.getElementById("continue-voting");
    continueButton.classList.remove("hidden");
    continueButton.addEventListener("click", () => {
      window.location.href = "vote.html";
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initializeStorage();
  setupThemeToggle();
  setupAuthHandlers();
  setupAutoRedirect();

  const loader = document.getElementById("page-loader");
  setTimeout(() => loader.classList.add("hidden"), 450);
});
